﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAjoutInventaire
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAjoutInventaire))
        Me.txtNom = New System.Windows.Forms.TextBox()
        Me.cmbProduit = New System.Windows.Forms.ComboBox()
        Me.txtQuantite = New System.Windows.Forms.TextBox()
        Me.cmbUnite = New System.Windows.Forms.ComboBox()
        Me.txtDescription = New System.Windows.Forms.RichTextBox()
        Me.dtpReception = New System.Windows.Forms.DateTimePicker()
        Me.dtpPeremption = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnAjouter = New System.Windows.Forms.Button()
        Me.btnAnnuler = New System.Windows.Forms.Button()
        Me.lblEquivalence = New System.Windows.Forms.Label()
        Me.txtEquivalence = New System.Windows.Forms.TextBox()
        Me.cmbEquivalence = New System.Windows.Forms.ComboBox()
        Me.txtFormat = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtNom
        '
        Me.txtNom.Location = New System.Drawing.Point(155, 126)
        Me.txtNom.Name = "txtNom"
        Me.txtNom.Size = New System.Drawing.Size(321, 20)
        Me.txtNom.TabIndex = 0
        '
        'cmbProduit
        '
        Me.cmbProduit.FormattingEnabled = True
        Me.cmbProduit.Location = New System.Drawing.Point(155, 79)
        Me.cmbProduit.Name = "cmbProduit"
        Me.cmbProduit.Size = New System.Drawing.Size(201, 21)
        Me.cmbProduit.TabIndex = 1
        '
        'txtQuantite
        '
        Me.txtQuantite.Location = New System.Drawing.Point(155, 166)
        Me.txtQuantite.Name = "txtQuantite"
        Me.txtQuantite.Size = New System.Drawing.Size(92, 20)
        Me.txtQuantite.TabIndex = 2
        Me.txtQuantite.Text = "1"
        '
        'cmbUnite
        '
        Me.cmbUnite.FormattingEnabled = True
        Me.cmbUnite.Location = New System.Drawing.Point(255, 205)
        Me.cmbUnite.Name = "cmbUnite"
        Me.cmbUnite.Size = New System.Drawing.Size(71, 21)
        Me.cmbUnite.TabIndex = 3
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(155, 449)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(321, 96)
        Me.txtDescription.TabIndex = 4
        Me.txtDescription.Text = ""
        '
        'dtpReception
        '
        Me.dtpReception.Location = New System.Drawing.Point(156, 339)
        Me.dtpReception.Name = "dtpReception"
        Me.dtpReception.Size = New System.Drawing.Size(200, 20)
        Me.dtpReception.TabIndex = 5
        '
        'dtpPeremption
        '
        Me.dtpPeremption.Location = New System.Drawing.Point(156, 393)
        Me.dtpPeremption.MinDate = New Date(1988, 12, 26, 0, 0, 0, 0)
        Me.dtpPeremption.Name = "dtpPeremption"
        Me.dtpPeremption.Size = New System.Drawing.Size(200, 20)
        Me.dtpPeremption.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(80, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Produit :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(91, 129)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Nom :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(73, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Quantité : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(83, 208)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Format :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(59, 449)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Description :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(28, 342)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Date de réception :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(22, 395)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(106, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Date de péremption :"
        '
        'btnAjouter
        '
        Me.btnAjouter.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.btnAjouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAjouter.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnAjouter.ForeColor = System.Drawing.Color.White
        Me.btnAjouter.Location = New System.Drawing.Point(290, 573)
        Me.btnAjouter.Name = "btnAjouter"
        Me.btnAjouter.Size = New System.Drawing.Size(90, 35)
        Me.btnAjouter.TabIndex = 15
        Me.btnAjouter.Text = "Ajouter"
        Me.btnAjouter.UseVisualStyleBackColor = False
        '
        'btnAnnuler
        '
        Me.btnAnnuler.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.btnAnnuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnnuler.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnAnnuler.ForeColor = System.Drawing.Color.White
        Me.btnAnnuler.Location = New System.Drawing.Point(386, 573)
        Me.btnAnnuler.Name = "btnAnnuler"
        Me.btnAnnuler.Size = New System.Drawing.Size(90, 35)
        Me.btnAnnuler.TabIndex = 16
        Me.btnAnnuler.Text = "Annuler"
        Me.btnAnnuler.UseVisualStyleBackColor = False
        '
        'lblEquivalence
        '
        Me.lblEquivalence.AutoSize = True
        Me.lblEquivalence.Location = New System.Drawing.Point(16, 251)
        Me.lblEquivalence.Name = "lblEquivalence"
        Me.lblEquivalence.Size = New System.Drawing.Size(113, 13)
        Me.lblEquivalence.TabIndex = 17
        Me.lblEquivalence.Text = "Equivalence par unité:"
        '
        'txtEquivalence
        '
        Me.txtEquivalence.Location = New System.Drawing.Point(155, 248)
        Me.txtEquivalence.Name = "txtEquivalence"
        Me.txtEquivalence.Size = New System.Drawing.Size(91, 20)
        Me.txtEquivalence.TabIndex = 18
        '
        'cmbEquivalence
        '
        Me.cmbEquivalence.FormattingEnabled = True
        Me.cmbEquivalence.Location = New System.Drawing.Point(254, 248)
        Me.cmbEquivalence.Name = "cmbEquivalence"
        Me.cmbEquivalence.Size = New System.Drawing.Size(72, 21)
        Me.cmbEquivalence.TabIndex = 19
        '
        'txtFormat
        '
        Me.txtFormat.Location = New System.Drawing.Point(155, 206)
        Me.txtFormat.Name = "txtFormat"
        Me.txtFormat.Size = New System.Drawing.Size(92, 20)
        Me.txtFormat.TabIndex = 20
        Me.txtFormat.Text = "1"
        '
        'txtTotal
        '
        Me.txtTotal.Enabled = False
        Me.txtTotal.Location = New System.Drawing.Point(153, 295)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(91, 20)
        Me.txtTotal.TabIndex = 22
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(25, 298)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 13)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Total en inventaire :"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(258, 298)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(0, 13)
        Me.lblTotal.TabIndex = 23
        '
        'frmAjoutInventaire
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(521, 639)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtFormat)
        Me.Controls.Add(Me.cmbEquivalence)
        Me.Controls.Add(Me.txtEquivalence)
        Me.Controls.Add(Me.lblEquivalence)
        Me.Controls.Add(Me.btnAnnuler)
        Me.Controls.Add(Me.btnAjouter)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpPeremption)
        Me.Controls.Add(Me.dtpReception)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.cmbUnite)
        Me.Controls.Add(Me.txtQuantite)
        Me.Controls.Add(Me.cmbProduit)
        Me.Controls.Add(Me.txtNom)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAjoutInventaire"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ajouter dans l'inventaire"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNom As TextBox
    Friend WithEvents cmbProduit As ComboBox
    Friend WithEvents txtQuantite As TextBox
    Friend WithEvents cmbUnite As ComboBox
    Friend WithEvents txtDescription As RichTextBox
    Friend WithEvents dtpReception As DateTimePicker
    Friend WithEvents dtpPeremption As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnAjouter As Button
    Friend WithEvents btnAnnuler As Button
    Friend WithEvents lblEquivalence As Label
    Friend WithEvents txtEquivalence As TextBox
    Friend WithEvents cmbEquivalence As ComboBox
    Friend WithEvents txtFormat As TextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents lblTotal As Label
End Class
